# AudioLab
This repository uses sub-modules. To fully download, please use the command:

`git clone --recursive  https://github.com/SMU-MSLC-2016/AudioLab.git`
