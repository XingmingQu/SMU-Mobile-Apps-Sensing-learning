//
//  ViewController.m
//  AudioLab
//
//  Created by Eric Larson
//  Copyright © 2016 Eric Larson. All rights reserved.
//



//For thought

//Question 1:

//we increased the buffer size to twice and ten times and it worked like a charm!
//So the answer is YES, it will work.
//However, when the FFT magnitude becomes soooooooo large. Like length=10000000000,
//It will fail. Because there are no enough pixel points in the screen and the program will become very slow because of the large computation
//So we can just add the if statement to check if the length is larger than a threshold. If so, we can just truncate it to the threshold

//Question 2:

//Pausing the audio manager is better than deallocating it. Deallocating the audio manager means every time we go in the FFT plot view controller we have to re-init a object. This process is very time consuming. Assuming a user click the ICA cell and the back button very ofter, it will be a nightmare to re-init the object. 
//If we pause it, we will no longer need to init the object. That means we can reuse it every time.




#import "ViewController.h"
#import "Novocaine.h"
#import "CircularBuffer.h"
#import "SMUGraphHelper.h"
#import "FFTHelper.h"
#import "AudioFileReader.h"
#define BUFFER_SIZE 2048*2

@interface ViewController ()
@property (strong, nonatomic) Novocaine *audioManager;
@property (strong, nonatomic) CircularBuffer *buffer;
@property (strong, nonatomic) SMUGraphHelper *graphHelper;
@property (strong, nonatomic) FFTHelper *fftHelper;
@property (strong, nonatomic)  AudioFileReader *fileReader;
@end



@implementation ViewController

#pragma mark Lazy Instantiation

-(AudioFileReader*)fileReader{
    if(!_fileReader){
        NSURL *inputFileURL =[[NSBundle mainBundle] URLForResource:@"satisfaction" withExtension:@"mp3"];
        _fileReader = [[AudioFileReader alloc]
                       initWithAudioFileURL:inputFileURL samplingRate:self.audioManager.samplingRate
                       numChannels:self.audioManager.numOutputChannels];
    }
    return _fileReader;
}


-(Novocaine*)audioManager{
    if(!_audioManager){
        _audioManager = [Novocaine audioManager];
    }
    return _audioManager;
}

-(CircularBuffer*)buffer{
    if(!_buffer){
        _buffer = [[CircularBuffer alloc]initWithNumChannels:1 andBufferSize:BUFFER_SIZE];
    }
    return _buffer;
}

-(SMUGraphHelper*)graphHelper{
    if(!_graphHelper){
        _graphHelper = [[SMUGraphHelper alloc]initWithController:self
                                        preferredFramesPerSecond:15
                                                       numGraphs:3
                                                       plotStyle:PlotStyleSeparated
                                               maxPointsPerGraph:BUFFER_SIZE];
    }
    return _graphHelper;
}

-(FFTHelper*)fftHelper{
    if(!_fftHelper){
        _fftHelper = [[FFTHelper alloc]initWithFFTSize:BUFFER_SIZE];
    }
    
    return _fftHelper;
}


#pragma mark VC Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.fileReader play];
    self.fileReader.currentTime = 0.0;
   
    [self.graphHelper setFullScreenBounds];
    
    __block ViewController * __weak  weakSelf = self;
    [self.audioManager setOutputBlock:^(float *data, UInt32 numFrames, UInt32 numChannels){
        [weakSelf.fileReader retrieveFreshAudio:data numFrames:numFrames numChannels:numChannels];
        [weakSelf.buffer addNewFloatData:data withNumSamples:numFrames];
        NSLog(@"Time: %f", weakSelf.fileReader.currentTime);
    
    
//    [self.audioManager setInputBlock:^(float *data, UInt32 numFrames, UInt32 numChannels){
//        [weakSelf.buffer addNewFloatData:data withNumSamples:numFrames];
////    NSLog(@"%.f",data[1]);
//    }];
   
    }];
    [self.audioManager play];
}
// Part one:
// When view disappears, call the pause function of audio manager, so that it stops
//capturing the audio signals.
//
-(void)viewDidDisappear:(BOOL)animated{

    [self.audioManager pause];
}

#pragma mark GLK Inherited Functions
//  override the GLKViewController update function, from OpenGLES
- (void)update{
    // just plot the audio stream
    
    // get audio stream data
    float* arrayData = malloc(sizeof(float)*BUFFER_SIZE);
    float* fftMagnitude = malloc(sizeof(float)*BUFFER_SIZE/2);
    
    [self.buffer fetchFreshData:arrayData withNumSamples:BUFFER_SIZE];
    
    
    int windowLength = BUFFER_SIZE/40;
    
    // part two 3
    for(int i=0;i<20;i++){

        double peakValue=-10000000000000;

        for(int j=i*windowLength;j<(i+1)*windowLength;j++){

            if(fftMagnitude[j]>peakValue){
                peakValue=fftMagnitude[j];
//                NSLog(@"%f,changed",peakValue);
            }
        }
        peakArr[i] = peakValue;
    }
    
    
    double currentMax=peakArr[0];
    for(int i=1;i<20;i++){
        if (peakArr[i]>currentMax){
            currentMax=peakArr[i];
        }
    }
    
    
    
    
    //send off for graphing
    [self.graphHelper setGraphData:arrayData
                    withDataLength:BUFFER_SIZE
                     forGraphIndex:0];
    
    // take forward FFT
    [self.fftHelper performForwardFFTWithData:arrayData
                   andCopydBMagnitudeToBuffer:fftMagnitude];
    
    // graph the FFT Data
    [self.graphHelper setGraphData:fftMagnitude
                    withDataLength:BUFFER_SIZE/2
                     forGraphIndex:1
                 withNormalization:64.0
                     withZeroValue:-60];
    
    // Part two 1
    [self.graphHelper setGraphData:peakArr
                    withDataLength:20
                     forGraphIndex:2
                 withNormalization:currentMax
                     withZeroValue:-60];
    
    [self.graphHelper update]; // update the graph
    free(arrayData);
    free(fftMagnitude);
}

//  override the GLKView draw function, from OpenGLES
- (void)glkView:(GLKView *)view drawInRect:(CGRect)rect {
    [self.graphHelper draw]; // draw the graph
}


@end
