# AudioDSPUtils

This is a sub-module for use in the SMU mobile sensing course. 

It builds from another project: https://github.com/alexbw/novocaine 
But has been heavily manipulated to work with with buffered audio and to not use obj-c++.
