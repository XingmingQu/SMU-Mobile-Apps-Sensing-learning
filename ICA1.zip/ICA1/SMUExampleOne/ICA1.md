Team:
Xingming Qu, Alex Sun, Siddhika Ghaisas

For thought:
1.[4 points] Is this new implementation of the model more efficient? Why or Why not?
No. Because every time we have a new photo we have to hardcode the names and add it manually.

2.[3 points] Is this implementation of the model scalable? Why or Why not?
Kind of. In the part three, we added three additional images. We only need to hardcode image names and then the table view and the collection view will be automatically updated. 


3.[3 points] If there were 1000 images in the image.assets file, what would you change in the
implementation of the model?
To solve it, we can simply add a for loop to add all the NAMES of the photos since save strings in NSArray will not take too much string. When we want to access specific photos, we can index images by their names.

