//
//  ImageModel.m
//  SMUExampleOne
//
//  Created by Eric Larson on 1/21/15.
//  Copyright (c) 2015 Eric Larson. All rights reserved.
//

#import "ImageModel.h"

/*
 Update the ImageModel class to have all properties private, except the shared
 instance method
 */
@interface ImageModel()
@property (strong,nonatomic) NSArray* imageNames;
@property (strong,nonatomic) NSArray* loadedImage;
@end

@implementation ImageModel
@synthesize imageNames = _imageNames;
@synthesize loadedImage = _loadedImage;

-(NSArray*)imageNames{
    
    //    NSLog(@"%lu,in imageNames",(unsigned long)_imageNames.count);
    if(!_imageNames)
        _imageNames = @[@"Eric1",@"Eric2",@"Eric3",@"BMW",@"Lamborghini",@"Mustang"];
    //    NSLog(@"%lu",(unsigned long)_imageNames.count);
    return _imageNames;
}

//Update ImageModel class to pre-load all the images and save them into an NSArray.

-(NSArray*)loadedImage{
    //    NSLog(@"%lu",(unsigned long)_loadedImage.count);
    //    NSLog(@"%lu",(unsigned long)_loadedImage.count);
    if(!_loadedImage){
        _loadedImage = @[[UIImage imageNamed:@"Eric1"],[UIImage imageNamed:@"Eric2"],[UIImage imageNamed:@"Eric3"],[UIImage imageNamed:@"BMW"],[UIImage imageNamed:@"Lamborghini"],[UIImage imageNamed:@"Mustang"]];
    }
    //    NSLog(@"%lu,after",(unsigned long)_loadedImage.count);
    return _loadedImage;
}

+(ImageModel*)sharedInstance{
    static ImageModel * _sharedInstance = nil;
    
    static dispatch_once_t oncePredicate;
    
    dispatch_once(&oncePredicate,^{
        _sharedInstance = [[ImageModel alloc] init];
    });
    
    return _sharedInstance;
}

-(UIImage*)getImageWithName:(NSString *)name{
    UIImage* image = nil;
    image = [UIImage imageNamed:name];
    return image;
}


/*
 Modify or create functions that will allow other classes to access the image names
 and the images by sending in an NSInteger parameter (i.e., the input to the method is the index of the image in the array). Also add a methodthat returns the total number of images in the model
 */

-(NSUInteger)getTotalNumberOfImage{
    //        NSLog(@"%lu",(unsigned long)self.loadedImage.count);
    //    return self.loadedImage.count;
    if (self.imageNames.count != self.loadedImage.count) {
        NSLog(@"Please check NSArray* imageNames and NSArray* loadedimage. These two NSArray should have the same amount of images.");
    }
    
    return self.imageNames.count;
}


-(NSString*)getImageNamesByIndex:(NSInteger)index{
    //    NSLog(@"%@",[_imageNames objectAtIndex:0]);
    NSString* imName = [_imageNames objectAtIndex:index];
    return imName;
}


-(UIImage*)getLoadedImageByIndex:(NSInteger)index{
    //    NSString* name = [self getImageNamesByIndex:(index)];
    //    NSLog(@"%lu",(unsigned long)_loadedImage.count);
    //    UIImage* image = _loadedImage[index];
    //    UIImage* image = nil;
    //    image = [UIImage imageNamed:@"BMW"];
    //    NSLog(@"%lu",(unsigned long)self.loadedImage.count);
    UIImage* image = [_loadedImage objectAtIndex:index];
    return image;
}



@end
